package com.mindtree.bankuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
