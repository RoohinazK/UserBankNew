package com.mindtree.bankuser.exception;

public class UserNotPresentException extends ControllerServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNotPresentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserNotPresentException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public UserNotPresentException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public UserNotPresentException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public UserNotPresentException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
