package com.mindtree.bankuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankuserApplication.class, args);
	}

}
